# Result_analysis_csv_to_table_graph_pdf_output
Type 0 in SGPA column if student fails 
Add SGPAGRADES column at the end , Type F if student Dont have SGPA (means Fail)
Type 0 in SGPA column if student fails

  
## Setup

	requirement file is given 
	install it using pip as
		pip install -r requirement
	
	then run python file final.py from python3
		python3 final.py
### Note
	currently thios code is not adaptive nature needs csv file in same format no of subject may varry 
	first 2 column are neccesory
	
	
	
	
	
