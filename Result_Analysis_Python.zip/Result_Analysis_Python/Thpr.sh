#!/bin/bash
# Theory Analysis
a=0
rm *.csv &> /dev/null
echo "SGPAGRADES" > 9_S.csv
echo "Welcome to Automation of Result Analysis of SPPU PUNE"
echo "Enter File Name(including .pdf extention) .There should not be mistakes"
read -p "Enter Filename : " fn
read -p "Enter First 7 Digits of Seat Number : " sn
echo "Seat_number" > 0_1SNumber.csv
echo "Name of The Student" > 0_2SNames.csv
pdfgrep  $sn $fn |awk '{print $1}'|tr " " "," >> 0_1SNumber.csv
pdfgrep  $sn $fn |awk '{print $2,$3,$4}' >> 0_2SNames.csv

#echo $(wc -l 0_Names.csv) |echo $(awk '{print $1}') "Records Found Including Header "
k=$(echo $(wc -l 0_1SNumber.csv) |echo $(awk '{print $1}'))
        echo "........`expr $k - 1` Records Found......" 	
        if [ $k == "1" ]
	then
           rm 0_1SNumber.csv 0_2SNames.csv
	   echo "Seat Number Pattern Does not Exist"
           exit
	fi
read -p "Enter the Number of Theory Subjects: " th
while [ $a -lt $th ] 
do
	c=`expr $a + 1`	
	read -p "Enter Subject Code of $c : " scode
	read -p "Enter Short Name of Subject $c : " sname
	rm $scode.csv &> /dev/null
	echo "$sname""_MARKS","$sname""_GRADES","$sname""_CP" > $scode.csv
	pdfgrep -A 1  $scode $fn  | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode|tr " " ","  >> $scode.csv
	#Top 10
        #echo "Seat Number","Name of Student","MARKS" > $scodeTop.csv
        #paste 0_1SNumber.csv 0_2SNames.csv $scode.csv >  $scodeTop.csv
        #cat 410241Top.csv |tr "," " "|awk '{print $1,$2,$3,$4,$5}'|sort -r -k 5|head -n 11
        k=$(echo $(wc -l $scode.csv) |echo $(awk '{print $1}'))
        echo "........`expr $k - 1` Records Found......"
        if [ $k == "1" ]
	then
           rm $scode.csv
	   echo "subject code not existed"
           continue
	fi 
	#echo $(wc -l $scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in $scode Subject"
	file_array[$a]=$scode.csv
	a=`expr $a + 1`
done

if [ $a -eq 0 ]
then
	echo " No Subject..."
else
	rm 1_TH.csv &> /dev/null
	echo $(paste ${file_array[*]} > 1_TH.csv) 
	echo "1_TH.csv file is created with Theory Subject Details"
	rm ${file_array[*]}
fi


echo " Practial , Termwork and Oral Analysis will Begin....."
# Practical Analysis
# Terwork (Tw) and Practical (Pr)
a=0

read -p "How many Subjects having Both Terwork (Tw) and Practical (Pr)  " tw
while [ $a -lt $tw ] 
do
	c=`expr $a + 1`	
	read -p "Enter Subject Code of Termwork $c : " scode
	read -p "Enter Short Name of Subject $c : " sname
	rm TW$scode.csv PR$scode.csv &> /dev/null
	echo "$sname""_TWMARKS","$sname""_TWGRADES","$sname""_TWCP" > TW$scode.csv
        echo "$sname""_PRMARKS","$sname""_PRGRADES","$sname""_PRCP" > PR$scode.csv
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode |awk 'NR%2==1'|tr " " ",">> TW$scode.csv
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode |awk 'NR%2==0'|tr " " "," >> PR$scode.csv
        k=$(echo $(wc -l TW$scode.csv) |echo $(awk '{print $1}'))
        echo "........`expr $k - 1` Records Found......"
        if [ $k == "1" ]
	then
           rm TW$scode.csv PR$scode.csv &> /dev/null
	   echo "Subject code not existed"
           continue
	fi 
	#echo $(wc -l TW$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in TW$scode TW Subject"
	#echo $(wc -l PR$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in PR$scode PR Subject"
	TW_array[$a]=TW$scode.csv
	PR_array[$a]=PR$scode.csv
	a=`expr $a + 1`
done
if [ $a -eq 0 ]
then
	echo " No Subject..."
else
	rm 2_TWPR.csv &> /dev/null
	echo $(paste ${TW_array[*]} ${PR_array[*]} > 2_TWPR.csv)  
	echo "2_TWPR.csv file is created"
	rm TW$scode.csv PR$scode.csv &> /dev/null
fi




# Termwork and Oral
a=0

read -p "How many Subjects having Both Terwork (Tw) and Oral (OR)  " tor
while [ $a -lt $tor ] 
do
	c=`expr $a + 1`	
	read -p "Enter Subject Code of Termwork  and Oral $c : " scode
	read -p "Enter Short Name of Subject $c : " sname
	rm TW$scode.csv  OR$scode.csv&> /dev/null
	echo "$sname""_TWMARKS","$sname""_TWGRADES","$sname""_TWCP" > TW$scode.csv
        echo "$sname""_ORMARKS","$sname""_ORGRADES","$sname""_ORCP" > OR$scode.csv
	
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode |awk 'NR%2==1'|tr " " ",">> TW$scode.csv
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode |awk 'NR%2==0'|tr " " "," >> OR$scode.csv
        k=$(echo $(wc -l TW$scode.csv) |echo $(awk '{print $1}'))
        echo "........`expr $k - 1` Records Found......"
        if [ $k == "1" ]
	then
           rm TW$scode.csv OR$scode.csv &> /dev/null
	   echo "Subject code not existed"
           continue
	fi 
	#echo $(wc -l TW$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in TW$scode TW Subject"
	#echo $(wc -l OR$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in OR$scode OR Subject"
	TW_array[$a]=TW$scode.csv
	OR_array[$a]=OR$scode.csv
	a=`expr $a + 1`
done
if [ $a -eq 0 ]
then
	echo " No Subject..."
else
	rm 3_TWOR.csv &> /dev/null
	echo $(paste ${TW_array[*]} ${OR_array[*]} > 3_TWOR.csv) 
	echo "3_TWOR.csv file is created"
	rm TW$scode.csv OR$scode.csv &> /dev/null
fi

# Practical and Oral
a=0

read -p "How many Subjects having Both Practical (PR) and Oral (OR)  " tor
while [ $a -lt $tor ] 
do
	c=`expr $a + 1`	
	read -p "Enter Subject Code of Practical  and Oral $c : " scode
	read -p "Enter Short Name of Subject $c : " sname
	rm PR$scode.csv OR$scode.csv&> /dev/null
	
        echo "$sname""_PRMARKS","$sname""_PRGRADES","$sname""_PRCP" > PR$scode.csv
	echo "$sname""_ORMARKS","$sname""_ORGRADES","$sname""_ORCP" > OR$scode.csv

	
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode |awk 'NR%2==1'|tr " " ",">> PR$scode.csv
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode |awk 'NR%2==0'|tr " " "," >> OR$scode.csv
        k=$(echo $(wc -l PR$scode.csv) |echo $(awk '{print $1}'))
        echo "........`expr $k - 1` Records Found......"
        if [ $k == "1" ]
	then
           rm PR$scode.csv OR$scode.csv &> /dev/null
	   echo "Subject code not existed"
           continue
	fi 
	#echo $(wc -l PR$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in PR$scode PR Subject"
	#echo $(wc -l OR$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in OR$scode OR Subject"
	PR_array[$a]=PR$scode.csv
	OR_array[$a]=OR$scode.csv
	a=`expr $a + 1`
done
if [ $a -eq 0 ]
then
	echo " No Subject..."
else
	rm 4_PROR.csv &> /dev/null
	echo $(paste ${PR_array[*]} ${OR_array[*]} > 4_PROR.csv) 
	echo "4_PROR.csv file is created"
	rm PR$scode.csv OR$scode.csv &> /dev/null
fi

# Only Oral
a=0

read -p "How many Subjects having Only Oral (OR)  Exam " tor
while [ $a -lt $tor ] 
do
	c=`expr $a + 1`	
	read -p "Enter Subject Code of Oral Exam $c : " scode
	read -p "Enter Short Name of Subject $c : " sname
	rm OR$scode.csv &> /dev/null
	
        echo "$sname""_ORMARKS","$sname""_ORGRADES","$sname""_ORCP" > OR$scode.csv
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode |tr " " ",">> OR$scode.csv
        
        k=$(echo $(wc -l OR$scode.csv) |echo $(awk '{print $1}'))
        echo "........`expr $k - 1` Records Found......"
        if [ $k == "1" ]
	then
           rm  OR$scode.csv
	   echo "Subject code not existed"
           continue
	fi 
	
	#echo $(wc -l OR$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in OR$scode OR Subject"
	
	OR_array[$a]=OR$scode.csv
	a=`expr $a + 1`
done
if [ $a -eq 0 ]
then
	echo " No Subject..."
else
	rm 5_ORONLY.csv &> /dev/null
	echo $(paste ${OR_array[*]} > 5_ORONLY.csv) 
	echo "5_ORONLY.csv file is created "
	rm OR$scode.csv &> /dev/null
fi


# Only Termwork
a=0

read -p "How many Subjects having Only Term Work (TW)  Exam " tor
while [ $a -lt $tor ] 
do
	c=`expr $a + 1`	
	read -p "Enter Subject Code of Term Work Exam $c : " scode
	rm TW$scode.csv &> /dev/null
	
        echo "$sname""_TWMARKS","$sname""_TWGRADES","$sname""_TWCP" > TW$scode.csv
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode |tr " " ",">> TW$scode.csv
        
        k=$(echo $(wc -l TW$scode.csv) |echo $(awk '{print $1}'))
        echo "........`expr $k - 1` Records Found......"
        if [ $k == "1" ]
	then
           rm  TW$scode.csv
	   echo "Subject code not existed"
           continue
	fi 
	
	#echo $(wc -l TW$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in TW$scode TW Subject"
	
	TW_array[$a]=TW$scode.csv
	a=`expr $a + 1`
done
if [ $a -eq 0 ]
then
	echo " No Subject..."
else
	rm 6_TWONLY.csv &> /dev/null
	echo $(paste ${TW_array[*]} > 6_TWONLY.csv) 
	echo "6_TWONLY.csv file is created"
	rm TW$scode.csv &> /dev/null
fi

# Only Practical
a=0

read -p "How many Subjects having Only Practical (PR)  Exam " tor
while [ $a -lt $tor ] 
do
	c=`expr $a + 1`	
	read -p "Enter Subject Code of Term Work Exam $c : " scode
	read -p "Enter Short Name of Subject $c : " sname
	rm PR$scode.csv &> /dev/null
	
        echo "$sname""_PRMARKS","$sname""_PRGRADES","$sname""_PRCP" > PR$scode.csv
        pdfgrep -A 1 $scode $fn | awk '{print $1, $3, $5}' |grep -v -|grep -v $scode|tr " " ",">> PR$scode.csv
        
        k=$(echo $(wc -l PR$scode.csv) |echo $(awk '{print $1}'))
        echo "........`expr $k - 1` Records Found......"
        if [ $k == "1" ]
	then
           rm  PR$scode.csv
	   echo "Subject code not existed"
           continue
	fi 
	
	#echo $(wc -l PR$scode.csv) |echo $(awk '{print $1}') "Records Found Including Header in PR$scode PR Subject"
	
	PR_array[$a]=PR$scode.csv
	a=`expr $a + 1`
done
if [ $a -eq 0 ]
then
	echo " No Subject..."
else
	rm 7_PRONLY.csv &> /dev/null
	echo $(paste ${PR_array[*]} > 7_PRONLY.csv) 
	echo "7_PRONLY.csv file is created"
	rm PR$scode.csv &> /dev/null
fi

# For SGPA Fetching

echo "SGPA" > 8_sgpa.csv
pdfgrep FOURTH\ YEAR\ SGPA res.pdf | awk '{print $5}' |tr "," " "| sed 's/['--']/'0'/g' >> 8_sgpa.csv
pdfgrep FOURTH\ YEAR\ SGPA res.pdf | awk '{print $5}' |tr "," " "| sed 's/'--'/'F'/g' |sed 's/[0-9]//g'|sed 's/[.]//g' >> 9_S.csv
paste *.csv > complete.csv

echo "Completed"
echo ""
echo ""
echo " Check complete.csv file"


k=$(echo $(wc -l complete.csv) |echo $(awk '{print $1}'))
echo "........`expr $k - 1` Records Found......"

echo ""
echo ""
echo "Open the complete.csv file and check the Format is Ok or Not"
echo ""
echo ""

read -p "Press 1 If You want Detailed Analysis in .pdf: " a 
if [ $a -eq 1 ]
then
	python3 final.py
	echo "Check Analysis.pdf for More Details"
	echo "Analysis Done"
	echo "Thank You for Using This"
	echo ""
	echo ""
        echo "For More Details Contact me @ 9130002554"
	echo "Prof Sai Prasad, Dept of Comp Engg" 
	echo "Sanjivani College of Engineering, Kopargaon"

else
	exit
fi
 


#pdfgrep -A 1  410241 CEGABE2019.pdf  | awk '{print $1, $2, $3}' |grep -v -|grep -v 410241|tr " " ","  > 410241.csv
# -A 1 : lines After Matching
# -B 1 lines before matching
# grep -v - : Ignores lines matching -
#grep -v 410241: Ignores lines matching 410241
#tr " " ","  : Replace "space with comma(,)
#head -1 myfile.csv | sed 's/[^,]//g' | wc -c
#if count is 13, change $11 accordingly
# awk '{print $3}' complete.csv |tr "," " "|awk '{print $11'}





